module Main 
    (main) where

import Lib
import TestBlockfrost 

main :: IO ()
main = print "bonjour"


